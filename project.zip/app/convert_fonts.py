import glob, os
d = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src', 'main', 'assets', 'fonts')
try:
    from fontTools.ttLib import TTFont
    for f in glob.glob(os.path.join(d, '*.woff2')):
        t = TTFont(f)
        t.flavor = None
        t.save(f[:-len('.woff2')] + '.ttf')
        os.remove(f)
        print('converted', f)
except Exception as e:
    print('font conversion skipped:', e)
