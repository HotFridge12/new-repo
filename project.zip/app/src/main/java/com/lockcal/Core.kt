package com.lockcal

import android.Manifest
import android.app.WallpaperManager
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.*
import android.provider.CalendarContract
import androidx.core.graphics.PathParser
import androidx.work.*
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.TimeUnit

class Theme(
    val name: String, val bg: String, val title: String, val accent: String,
    val workFill: String, val workEdge: String, val workText: String,
    val offFill: String, val offEdge: String, val offText: String,
    val ring: String, val empty: String, val decor: Boolean
)

val THEMES = listOf(
    Theme("Night (original)", "#04050c", "#f5d36b", "#b9a7ff", "#a81d3c", "#d9546f", "#ffffff",
        "#17c28a", "#7ff0c9", "#02281c", "#f5d36b", "#1d2040", true),
    Theme("Sunset", "#1a0b1e", "#ffb86b", "#ff9ec4", "#c2410c", "#fb923c", "#ffffff",
        "#0e7490", "#67e8f9", "#ecfeff", "#ffe08a", "#3b1d3f", true),
    Theme("Forest", "#07130d", "#d9f99d", "#86efac", "#15803d", "#4ade80", "#ffffff",
        "#f59e0b", "#fde68a", "#3b2a00", "#fef3c7", "#14301f", true),
    Theme("Ocean", "#040b17", "#7dd3fc", "#a5b4fc", "#1d4ed8", "#60a5fa", "#ffffff",
        "#f472b6", "#fbcfe8", "#4a0420", "#fde68a", "#12203a", true),
    Theme("Mono", "#000000", "#ffffff", "#9ca3af", "#374151", "#6b7280", "#ffffff",
        "#e5e7eb", "#ffffff", "#111827", "#fbbf24", "#1f2937", false)
)

class Cfg(context: Context) {
    val ctx: Context = context.applicationContext
    private val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    var title: String
        get() = p.getString("title", "Work & Day Off") ?: ""
        set(v) { p.edit().putString("title", v).apply() }
    var note: String
        get() = p.getString("note", "") ?: ""
        set(v) { p.edit().putString("note", v).apply() }
    var start: LocalDate
        get() = LocalDate.ofEpochDay(p.getLong("start", LocalDate.of(2026, 10, 21).toEpochDay()))
        set(v) { p.edit().putLong("start", v.toEpochDay()).apply() }
    var end: LocalDate
        get() = LocalDate.ofEpochDay(p.getLong("end", LocalDate.of(2026, 11, 20).toEpochDay()))
        set(v) { p.edit().putLong("end", v.toEpochDay()).apply() }
    var off: Set<Long>
        get() = p.getStringSet("off", null)?.map { it.toLong() }?.toSet()
            ?: listOf(
                LocalDate.of(2026, 10, 24), LocalDate.of(2026, 10, 29), LocalDate.of(2026, 11, 2),
                LocalDate.of(2026, 11, 7), LocalDate.of(2026, 11, 13), LocalDate.of(2026, 11, 14),
                LocalDate.of(2026, 11, 18)
            ).map { it.toEpochDay() }.toSet()
        set(v) { p.edit().putStringSet("off", v.map { it.toString() }.toSet()).apply() }
    var theme: Int
        get() = p.getInt("theme", 0)
        set(v) { p.edit().putInt("theme", v).apply() }
    var dots: Boolean
        get() = p.getBoolean("dots", false)
        set(v) { p.edit().putBoolean("dots", v).apply() }
    var photo: Boolean
        get() = p.getBoolean("photo", false)
        set(v) { p.edit().putBoolean("photo", v).apply() }
    var dim: Int
        get() = p.getInt("dim", 55)
        set(v) { p.edit().putInt("dim", v).apply() }
    var lastSet: Long
        get() = p.getLong("last", -1L)
        set(v) { p.edit().putLong("last", v).apply() }
}

object Cal {
    fun has(ctx: Context) =
        ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    // number of calendar events on each day between from and to
    fun counts(ctx: Context, from: LocalDate, to: LocalDate): Map<LocalDate, Int> {
        val out = HashMap<LocalDate, Int>()
        if (!has(ctx)) return out
        val zone = ZoneId.systemDefault()
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, from.atStartOfDay(zone).toInstant().toEpochMilli())
        ContentUris.appendId(b, to.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli())
        try {
            val proj = arrayOf(
                CalendarContract.Instances.BEGIN, CalendarContract.Instances.END,
                CalendarContract.Instances.ALL_DAY
            )
            ctx.contentResolver.query(b.build(), proj, null, null, null)?.use { c ->
                while (c.moveToNext()) {
                    val z: ZoneId = if (c.getInt(2) == 1) ZoneOffset.UTC else zone
                    val begin = c.getLong(0)
                    val last = maxOf(c.getLong(1) - 1L, begin)
                    val s = Instant.ofEpochMilli(begin).atZone(z).toLocalDate()
                    val en = Instant.ofEpochMilli(last).atZone(z).toLocalDate()
                    var d = if (s.isBefore(from)) from else s
                    val stop = if (en.isAfter(to)) to else en
                    while (!d.isAfter(stop)) {
                        out[d] = (out[d] ?: 0) + 1
                        d = d.plusDays(1)
                    }
                }
            }
        } catch (e: Exception) {
        }
        return out
    }
}

object Renderer {
    const val W = 720
    const val H = 1600
    private const val GRID_TOP = 351f
    private const val SPARK = "M12 0C12.8 8 16 11.2 24 12 16 12.8 12.8 16 12 24 11.2 16 8 12.8 0 12 8 11.2 11.2 8 12 0Z"
    private const val MOON = "M62 8A44 44 0 1 0 92 68A36 36 0 1 1 62 8Z"

    private val sparks = listOf(
        floatArrayOf(238f, 92f, 10f), floatArrayOf(316f, 205f, 16f), floatArrayOf(338f, 118f, 9f),
        floatArrayOf(232f, 205f, 12f), floatArrayOf(28f, 728f, 12f), floatArrayOf(196f, 744f, 14f),
        floatArrayOf(120f, 776f, 9f), floatArrayOf(252f, 778f, 8f)
    )
    private val stars = listOf(
        floatArrayOf(270f, 60f, .8f), floatArrayOf(340f, 85f, .6f), floatArrayOf(300f, 190f, .7f),
        floatArrayOf(255f, 235f, .5f), floatArrayOf(345f, 240f, .6f), floatArrayOf(60f, 715f, .6f),
        floatArrayOf(160f, 760f, .7f), floatArrayOf(90f, 740f, .5f), floatArrayOf(225f, 720f, .6f),
        floatArrayOf(20f, 775f, .5f), floatArrayOf(335f, 785f, .6f), floatArrayOf(280f, 750f, .4f)
    )

    private fun lead(cfg: Cfg) = cfg.start.dayOfWeek.value % 7
    private fun days(cfg: Cfg) = ChronoUnit.DAYS.between(cfg.start, cfg.end).toInt() + 1
    private fun rowsOf(cfg: Cfg) = (lead(cfg) + days(cfg) + 6) / 7
    private fun md(d: LocalDate) =
        d.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).uppercase() + " " + d.dayOfMonth

    fun cell(cfg: Cfg, i: Int): RectF {
        val h = if (rowsOf(cfg) > 5) 52f else 62f
        val cw = (340f - 24f) / 7f
        val x = 10f + (i % 7) * (cw + 4f)
        val y = GRID_TOP + (i / 7) * (h + 4f)
        return RectF(x, y, x + cw, y + h)
    }

    // x,y in the 360x800 design space
    fun dateAt(cfg: Cfg, x: Float, y: Float): LocalDate? {
        var d = cfg.start
        var k = 0
        while (!d.isAfter(cfg.end)) {
            if (cell(cfg, lead(cfg) + k).contains(x, y)) return d
            d = d.plusDays(1)
            k++
        }
        return null
    }

    private fun font(ctx: Context, file: String, wght: Int, fb: Typeface): Typeface {
        val path = "fonts/$file"
        val a = try {
            Typeface.Builder(ctx.assets, path).setFontVariationSettings("'wght' $wght").build()
        } catch (e: Exception) { null }
        if (a != null) return a
        val b = try { Typeface.Builder(ctx.assets, path).build() } catch (e: Exception) { null }
        return b ?: fb
    }

    fun render(cfg: Cfg, today: LocalDate): Bitmap {
        val th = THEMES[cfg.theme.coerceIn(0, THEMES.size - 1)]
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.scale(W / 360f, H / 800f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        val photoFile = File(cfg.ctx.filesDir, "bg.jpg")
        val photo = if (cfg.photo && photoFile.exists()) BitmapFactory.decodeFile(photoFile.path) else null
        if (photo != null) {
            cv.drawBitmap(photo, null, RectF(0f, 0f, 360f, 800f), Paint(Paint.FILTER_BITMAP_FLAG))
            cv.drawColor(Color.argb(cfg.dim.coerceIn(0, 95) * 255 / 100, 0, 0, 0))
        } else {
            cv.drawColor(Color.parseColor(th.bg))
        }

        val serif = font(cfg.ctx, "cormorant.ttf", 600, Typeface.create(Typeface.SERIF, Typeface.BOLD))
        val sans = font(cfg.ctx, "dmsans.ttf", 500, Typeface.create("sans-serif-medium", Typeface.NORMAL))
        val bold = font(cfg.ctx, "dmsans.ttf", 700, Typeface.create("sans-serif", Typeface.BOLD))

        fun shape(d: String, x: Float, y: Float, s: Float) {
            val path = PathParser.createPathFromPathData(d)
            val m = Matrix()
            m.setScale(s, s)
            m.postTranslate(x, y)
            path.transform(m)
            cv.drawPath(path, p)
        }
        fun txt(s: String, x: Float, y: Float, size: Float, color: String, tf: Typeface,
                sp: Float = 0f, al: Paint.Align = Paint.Align.CENTER) {
            p.reset()
            p.isAntiAlias = true
            p.textAlign = al
            p.textSize = size
            p.typeface = tf
            p.color = Color.parseColor(color)
            p.letterSpacing = sp / size
            cv.drawText(s, x, y, p)
        }

        // sky decoration
        if (photo == null && th.decor) {
            p.color = Color.parseColor(th.title)
            shape(MOON, 252f, 96f, 0.7f)
            for (s in sparks) shape(SPARK, s[0], s[1], s[2] / 24f)
            p.color = Color.WHITE
            for (s in stars) {
                p.alpha = (s[2] * 255).toInt()
                cv.drawCircle(s[0] + 1f, s[1] + 1f, 1f, p)
            }
        }

        // header
        txt(cfg.title, 180f, 304f, 26f, th.title, serif, 1f)
        txt(md(cfg.start) + " – " + md(cfg.end), 180f, 322f, 11f, th.accent, sans, 2f)
        val cw = (340f - 24f) / 7f
        listOf("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT").forEachIndexed { i, s ->
            txt(s, 10f + i * (cw + 4f) + cw / 2f, 343f, 10f, th.accent, sans, 1f)
        }

        val n = days(cfg)
        val rows = rowsOf(cfg)
        val cellH = if (rows > 5) 52f else 62f
        val oy = (cellH - 62f) / 2f

        // empty (outside range) cells
        val dash = DashPathEffect(floatArrayOf(4f, 3f), 0f)
        for (i in 0 until rows * 7) {
            if ((i - lead(cfg)) in 0 until n) continue
            p.reset()
            p.isAntiAlias = true
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f
            p.color = Color.parseColor(th.empty)
            p.pathEffect = dash
            cv.drawRoundRect(cell(cfg, i), 9f, 9f, p)
        }

        // day cells
        val off = cfg.off
        val events: Map<LocalDate, Int> =
            if (cfg.dots) Cal.counts(cfg.ctx, cfg.start, cfg.end) else emptyMap()
        for (k in 0 until n) {
            val d = cfg.start.plusDays(k.toLong())
            val r = cell(cfg, lead(cfg) + k)
            val isOff = d.toEpochDay() in off
            val isToday = d == today
            val box = RectF(r)
            box.inset(-16f, -16f)
            cv.saveLayerAlpha(box, if (d.isBefore(today)) 90 else 255)

            p.reset()
            p.isAntiAlias = true
            p.style = Paint.Style.FILL
            p.color = Color.parseColor(if (isOff) th.offFill else th.workFill)
            if (isOff) p.setShadowLayer(12f, 0f, 0f, Color.parseColor("#8C" + th.offFill.substring(1)))
            cv.drawRoundRect(r, 9f, 9f, p)

            p.reset()
            p.isAntiAlias = true
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f
            p.color = Color.parseColor(if (isOff) th.offEdge else th.workEdge)
            cv.drawRoundRect(r, 9f, 9f, p)

            if (isToday) {
                p.reset()
                p.isAntiAlias = true
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2.5f
                p.color = Color.parseColor(th.ring)
                p.setShadowLayer(10f, 0f, 0f, Color.parseColor("#CC" + th.ring.substring(1)))
                val rr = RectF(r)
                rr.inset(-1.5f, -1.5f)
                cv.drawRoundRect(rr, 10f, 10f, p)
            }

            val fg = if (isOff) th.offText else th.workText
            val label = when {
                isToday -> "TODAY"
                k == 0 || d.dayOfMonth == 1 ->
                    d.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).uppercase()
                else -> ""
            }
            if (label.isNotEmpty()) {
                txt(label, r.centerX(), r.top + oy + 15.5f, 9f,
                    if (isToday && !isOff) th.ring else fg, bold, 1f)
            }
            txt(d.dayOfMonth.toString(), r.centerX(), r.top + oy + 35.5f, 19f, fg, bold)
            txt(if (isOff) "off" else "work", r.centerX(), r.top + oy + 51.5f, 10f, fg, sans, 0.6f)

            val cnt = events[d] ?: 0
            for (j in 0 until minOf(cnt, 3)) {
                p.reset()
                p.isAntiAlias = true
                p.color = Color.parseColor(fg)
                cv.drawCircle(r.right - 7f - j * 6f, r.top + 8f, 2f, p)
            }
            cv.restore()
        }

        // legend
        val gridBottom = GRID_TOP + rows * cellH + (rows - 1) * 4f
        val ly = gridBottom + 14f
        fun swatch(x: Float, fill: String, edge: String) {
            p.reset()
            p.isAntiAlias = true
            p.color = Color.parseColor(fill)
            cv.drawRoundRect(x, ly, x + 12f, ly + 12f, 4f, 4f, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f
            p.color = Color.parseColor(edge)
            cv.drawRoundRect(x, ly, x + 12f, ly + 12f, 4f, 4f, p)
        }
        swatch(117f, th.workFill, th.workEdge)
        txt("Work", 135f, ly + 10f, 11f, "#e8e6ff", sans, 0f, Paint.Align.LEFT)
        swatch(183f, th.offFill, th.offEdge)
        txt("Day off", 201f, ly + 10f, 11f, "#e8e6ff", sans, 0f, Paint.Align.LEFT)

        // progress bar + countdown
        val by = ly + 34f
        val done = (ChronoUnit.DAYS.between(cfg.start, today) + 1).coerceIn(0L, n.toLong()).toFloat()
        p.reset()
        p.isAntiAlias = true
        p.color = Color.parseColor(th.empty)
        cv.drawRoundRect(10f, by, 350f, by + 4f, 2f, 2f, p)
        if (done > 0f) {
            p.color = Color.parseColor(th.accent)
            cv.drawRoundRect(10f, by, 10f + 340f * done / n, by + 4f, 2f, 2f, p)
        }
        val left = ChronoUnit.DAYS.between(today, cfg.end).coerceAtLeast(0L)
        val workLeft = (0 until n).count { k ->
            val d = cfg.start.plusDays(k.toLong())
            !d.isBefore(today) && d.toEpochDay() !in off
        }
        val msg = when {
            today.isAfter(cfg.end) -> "PERIOD ENDED"
            today.isBefore(cfg.start) -> "STARTS IN " + ChronoUnit.DAYS.between(today, cfg.start) + " DAYS"
            else -> "$left DAYS LEFT  ·  $workLeft WORK DAYS"
        }
        txt(msg, 180f, by + 22f, 10f, th.accent, sans, 1f)

        // custom note
        val note = cfg.note.trim()
        if (note.isNotEmpty()) {
            var sz = 13f
            p.reset()
            p.isAntiAlias = true
            p.typeface = serif
            p.textSize = sz
            while (sz > 8f && p.measureText(note) > 240f) {
                sz -= 0.5f
                p.textSize = sz
            }
            txt(note, 180f, by + 46f, sz, th.title, serif, 0.5f)
        }
        return bmp
    }
}

fun applyLockScreen(ctx: Context) {
    val cfg = Cfg(ctx)
    val today = LocalDate.now()
    val bmp = Renderer.render(cfg, today)
    WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
    cfg.lastSet = today.toEpochDay()
}

class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            if (Cfg(applicationContext).lastSet != LocalDate.now().toEpochDay()) applyLockScreen(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

fun schedule(ctx: Context) {
    WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
        "daily", ExistingPeriodicWorkPolicy.KEEP,
        PeriodicWorkRequestBuilder<DailyWorker>(3, TimeUnit.HOURS).build()
    )
}
