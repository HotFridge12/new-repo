package com.lockcal

import android.app.WallpaperManager
import android.content.Context
import android.graphics.*
import androidx.core.graphics.PathParser
import androidx.work.*
import java.time.LocalDate
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.TimeUnit

class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    var title: String
        get() = p.getString("title", "Work & Day Off") ?: ""
        set(v) { p.edit().putString("title", v).apply() }
    var start: LocalDate
        get() = LocalDate.ofEpochDay(p.getLong("start", LocalDate.of(2026, 10, 21).toEpochDay()))
        set(v) { p.edit().putLong("start", v.toEpochDay()).apply() }
    var end: LocalDate
        get() = LocalDate.ofEpochDay(p.getLong("end", LocalDate.of(2026, 11, 20).toEpochDay()))
        set(v) { p.edit().putLong("end", v.toEpochDay()).apply() }
    var off: Set<Long>
        get() = p.getStringSet("off", null)?.map { it.toLong() }?.toSet()
            ?: listOf(
                LocalDate.of(2026, 10, 24), LocalDate.of(2026, 10, 29), LocalDate.of(2026, 11, 2),
                LocalDate.of(2026, 11, 7), LocalDate.of(2026, 11, 13), LocalDate.of(2026, 11, 14),
                LocalDate.of(2026, 11, 18)
            ).map { it.toEpochDay() }.toSet()
        set(v) { p.edit().putStringSet("off", v.map { it.toString() }.toSet()).apply() }
    var lastSet: Long
        get() = p.getLong("last", -1L)
        set(v) { p.edit().putLong("last", v).apply() }
}

object Renderer {
    const val W = 720
    const val H = 1600
    private const val GRID_TOP = 351f
    private const val GOLD = "#f5d36b"
    private const val LILAC = "#b9a7ff"
    private const val SPARK = "M12 0C12.8 8 16 11.2 24 12 16 12.8 12.8 16 12 24 11.2 16 8 12.8 0 12 8 11.2 11.2 8 12 0Z"
    private const val MOON = "M62 8A44 44 0 1 0 92 68A36 36 0 1 1 62 8Z"

    private val sparks = listOf(
        floatArrayOf(238f, 92f, 10f), floatArrayOf(316f, 205f, 16f), floatArrayOf(338f, 118f, 9f),
        floatArrayOf(232f, 205f, 12f), floatArrayOf(28f, 728f, 12f), floatArrayOf(196f, 744f, 14f),
        floatArrayOf(120f, 776f, 9f), floatArrayOf(252f, 778f, 8f)
    )
    private val stars = listOf(
        floatArrayOf(270f, 60f, .8f), floatArrayOf(340f, 85f, .6f), floatArrayOf(300f, 190f, .7f),
        floatArrayOf(255f, 235f, .5f), floatArrayOf(345f, 240f, .6f), floatArrayOf(60f, 715f, .6f),
        floatArrayOf(160f, 760f, .7f), floatArrayOf(90f, 740f, .5f), floatArrayOf(225f, 720f, .6f),
        floatArrayOf(20f, 775f, .5f), floatArrayOf(335f, 785f, .6f), floatArrayOf(280f, 750f, .4f)
    )

    private fun lead(cfg: Cfg) = cfg.start.dayOfWeek.value % 7
    private fun md(d: LocalDate) =
        d.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).uppercase() + " " + d.dayOfMonth

    fun cell(i: Int): RectF {
        val cw = (340f - 24f) / 7f
        val x = 10f + (i % 7) * (cw + 4f)
        val y = GRID_TOP + (i / 7) * 66f
        return RectF(x, y, x + cw, y + 62f)
    }

    // x,y in the 360x800 design space
    fun dateAt(cfg: Cfg, x: Float, y: Float): LocalDate? {
        var d = cfg.start
        var k = 0
        while (!d.isAfter(cfg.end)) {
            if (cell(lead(cfg) + k).contains(x, y)) return d
            d = d.plusDays(1); k++
        }
        return null
    }

    fun render(cfg: Cfg, today: LocalDate): Bitmap {
        val bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.scale(W / 360f, H / 800f)
        cv.drawColor(Color.parseColor("#04050c"))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val serif = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        val sans = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        val bold = Typeface.create("sans-serif", Typeface.BOLD)

        fun shape(d: String, x: Float, y: Float, s: Float) {
            val path = PathParser.createPathFromPathData(d)
            val m = Matrix()
            m.setScale(s, s)
            m.postTranslate(x, y)
            path.transform(m)
            cv.drawPath(path, p)
        }
        fun txt(s: String, x: Float, y: Float, size: Float, color: String, tf: Typeface,
                sp: Float = 0f, al: Paint.Align = Paint.Align.CENTER) {
            p.reset()
            p.isAntiAlias = true
            p.textAlign = al
            p.textSize = size
            p.typeface = tf
            p.color = Color.parseColor(color)
            p.letterSpacing = sp / size
            cv.drawText(s, x, y, p)
        }

        // night sky
        p.color = Color.parseColor(GOLD)
        shape(MOON, 252f, 96f, 0.7f)
        for (s in sparks) shape(SPARK, s[0], s[1], s[2] / 24f)
        p.color = Color.WHITE
        for (s in stars) {
            p.alpha = (s[2] * 255).toInt()
            cv.drawCircle(s[0] + 1f, s[1] + 1f, 1f, p)
        }

        // header
        txt(cfg.title, 180f, 304f, 26f, GOLD, serif, 1f)
        txt(md(cfg.start) + " – " + md(cfg.end), 180f, 322f, 11f, LILAC, sans, 2f)
        val cw = (340f - 24f) / 7f
        listOf("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT").forEachIndexed { i, s ->
            txt(s, 10f + i * (cw + 4f) + cw / 2f, 343f, 10f, LILAC, sans, 1f)
        }

        val n = ChronoUnit.DAYS.between(cfg.start, cfg.end).toInt() + 1
        val rows = (lead(cfg) + n + 6) / 7

        // empty (outside range) cells
        val dash = DashPathEffect(floatArrayOf(4f, 3f), 0f)
        for (i in 0 until rows * 7) {
            if ((i - lead(cfg)) in 0 until n) continue
            p.reset()
            p.isAntiAlias = true
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f
            p.color = Color.parseColor("#1d2040")
            p.pathEffect = dash
            cv.drawRoundRect(cell(i), 9f, 9f, p)
        }

        // day cells
        val off = cfg.off
        for (k in 0 until n) {
            val d = cfg.start.plusDays(k.toLong())
            val r = cell(lead(cfg) + k)
            val isOff = d.toEpochDay() in off
            val isToday = d == today
            val box = RectF(r)
            box.inset(-16f, -16f)
            cv.saveLayerAlpha(box, if (d.isBefore(today)) 90 else 255)

            p.reset()
            p.isAntiAlias = true
            p.style = Paint.Style.FILL
            p.color = Color.parseColor(if (isOff) "#17c28a" else "#a81d3c")
            if (isOff) p.setShadowLayer(12f, 0f, 0f, Color.parseColor("#8C17C28A"))
            cv.drawRoundRect(r, 9f, 9f, p)

            p.reset()
            p.isAntiAlias = true
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f
            p.color = Color.parseColor(if (isOff) "#7ff0c9" else "#d9546f")
            cv.drawRoundRect(r, 9f, 9f, p)

            if (isToday) {
                p.reset()
                p.isAntiAlias = true
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2.5f
                p.color = Color.parseColor(GOLD)
                p.setShadowLayer(10f, 0f, 0f, Color.parseColor("#CCF5D36B"))
                val rr = RectF(r)
                rr.inset(-1.5f, -1.5f)
                cv.drawRoundRect(rr, 10f, 10f, p)
            }

            val fg = if (isOff) "#02281c" else "#ffffff"
            val label = when {
                isToday -> "TODAY"
                k == 0 || d.dayOfMonth == 1 ->
                    d.month.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).uppercase()
                else -> ""
            }
            if (label.isNotEmpty()) {
                txt(label, r.centerX(), r.top + 15.5f, 9f,
                    if (isToday && !isOff) GOLD else fg, bold, 1f)
            }
            txt(d.dayOfMonth.toString(), r.centerX(), r.top + 35.5f, 19f, fg, bold)
            txt(if (isOff) "off" else "work", r.centerX(), r.top + 51.5f, 10f, fg, sans, 0.6f)
            cv.restore()
        }

        // legend
        val gridBottom = GRID_TOP + rows * 62f + (rows - 1) * 4f
        val ly = gridBottom + 14f
        fun swatch(x: Float, fill: String, edge: String) {
            p.reset()
            p.isAntiAlias = true
            p.color = Color.parseColor(fill)
            cv.drawRoundRect(x, ly, x + 12f, ly + 12f, 4f, 4f, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f
            p.color = Color.parseColor(edge)
            cv.drawRoundRect(x, ly, x + 12f, ly + 12f, 4f, 4f, p)
        }
        swatch(117f, "#a81d3c", "#d9546f")
        txt("Work", 135f, ly + 10f, 11f, "#e8e6ff", sans, 0f, Paint.Align.LEFT)
        swatch(183f, "#17c28a", "#7ff0c9")
        txt("Day off", 201f, ly + 10f, 11f, "#e8e6ff", sans, 0f, Paint.Align.LEFT)

        // progress bar + countdown
        val by = ly + 34f
        val done = (ChronoUnit.DAYS.between(cfg.start, today) + 1).coerceIn(0L, n.toLong()).toFloat()
        p.reset()
        p.isAntiAlias = true
        p.color = Color.parseColor("#1d2040")
        cv.drawRoundRect(10f, by, 350f, by + 4f, 2f, 2f, p)
        if (done > 0f) {
            p.color = Color.parseColor(LILAC)
            cv.drawRoundRect(10f, by, 10f + 340f * done / n, by + 4f, 2f, 2f, p)
        }
        val left = ChronoUnit.DAYS.between(today, cfg.end).coerceAtLeast(0L)
        val workLeft = (0 until n).count { k ->
            val d = cfg.start.plusDays(k.toLong())
            !d.isBefore(today) && d.toEpochDay() !in off
        }
        val msg = when {
            today.isAfter(cfg.end) -> "PERIOD ENDED"
            today.isBefore(cfg.start) -> "STARTS IN " + ChronoUnit.DAYS.between(today, cfg.start) + " DAYS"
            else -> "$left DAYS LEFT  ·  $workLeft WORK DAYS"
        }
        txt(msg, 180f, by + 22f, 10f, LILAC, sans, 1f)
        return bmp
    }
}

fun applyLockScreen(ctx: Context) {
    val cfg = Cfg(ctx)
    val today = LocalDate.now()
    val bmp = Renderer.render(cfg, today)
    WallpaperManager.getInstance(ctx).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
    cfg.lastSet = today.toEpochDay()
}

class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        return try {
            if (Cfg(applicationContext).lastSet != LocalDate.now().toEpochDay()) applyLockScreen(applicationContext)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

fun schedule(ctx: Context) {
    WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
        "daily", ExistingPeriodicWorkPolicy.KEEP,
        PeriodicWorkRequestBuilder<DailyWorker>(3, TimeUnit.HOURS).build()
    )
}
