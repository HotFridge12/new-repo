package com.lockcal

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.media.ExifInterface
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var preview: ImageView
    private lateinit var startBtn: Button
    private lateinit var endBtn: Button
    private lateinit var dotsSwitch: Switch
    private val fmt = DateTimeFormatter.ofPattern("MMM d, yyyy")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        schedule(this)
        scheduleMidnight(this)

        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun label(s: String): TextView {
            val t = TextView(this)
            t.text = s
            t.setTextColor(Color.parseColor("#b9a7ff"))
            t.setPadding(0, pad / 2, 0, 0)
            return t
        }
        fun button(s: String, f: () -> Unit): Button {
            val b = Button(this)
            b.text = s
            b.setOnClickListener { f() }
            return b
        }
        fun watcher(f: (String) -> Unit) = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { f(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        }

        // preview (tap a day to toggle work / day off)
        preview = ImageView(this)
        val w = (resources.displayMetrics.widthPixels * 0.8).toInt()
        val lp = LinearLayout.LayoutParams(w, w * Renderer.H / Renderer.W)
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.topMargin = pad
        preview.layoutParams = lp
        preview.scaleType = ImageView.ScaleType.FIT_XY
        preview.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val d = Renderer.dateAt(cfg, e.x / v.width * 360f, e.y / v.height * 800f)
                if (d != null) {
                    val s = cfg.off.toMutableSet()
                    if (!s.remove(d.toEpochDay())) s.add(d.toEpochDay())
                    cfg.off = s
                    refresh()
                }
            }
            true
        }

        val setBtn = button("Set as lock screen now") {
            Thread {
                try {
                    applyLockScreen(this)
                    runOnUiThread { toast("Lock screen updated") }
                } catch (e: Exception) {
                    runOnUiThread { toast("Failed: " + e.message) }
                }
            }.start()
        }

        val title = EditText(this)
        title.setText(cfg.title)
        title.hint = "Title"
        title.setTextColor(Color.WHITE)
        title.setHintTextColor(Color.GRAY)
        title.addTextChangedListener(watcher { cfg.title = it; refresh() })

        val note = EditText(this)
        note.setText(cfg.note)
        note.hint = "Note under the calendar (optional)"
        note.setTextColor(Color.WHITE)
        note.setHintTextColor(Color.GRAY)
        note.filters = arrayOf(InputFilter.LengthFilter(60))
        note.addTextChangedListener(watcher { cfg.note = it; refresh() })

        val spin = Spinner(this)
        spin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, THEMES.map { it.name })
        spin.setSelection(cfg.theme.coerceIn(0, THEMES.size - 1))
        spin.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (cfg.theme != pos) { cfg.theme = pos; refresh() }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        startBtn = Button(this)
        endBtn = Button(this)
        startBtn.setOnClickListener { pick(cfg.start) { cfg.start = it; refresh() } }
        endBtn.setOnClickListener { pick(cfg.end) { cfg.end = it; refresh() } }

        dotsSwitch = Switch(this)
        dotsSwitch.text = "Show dots for phone calendar events"
        dotsSwitch.setTextColor(Color.WHITE)
        dotsSwitch.isChecked = cfg.dots && Cal.has(this)
        dotsSwitch.setOnCheckedChangeListener { _, on ->
            if (on && !Cal.has(this)) {
                requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), 9)
            } else {
                cfg.dots = on
                refresh()
            }
        }

        val pickBtn = button("Choose photo") {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            startActivityForResult(i, 7)
        }
        val clearBtn = button("Remove photo") { cfg.photo = false; refresh() }
        val photoRow = LinearLayout(this)
        photoRow.orientation = LinearLayout.HORIZONTAL
        photoRow.addView(pickBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        photoRow.addView(clearBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val seek = SeekBar(this)
        seek.max = 90
        seek.progress = cfg.dim
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                if (fromUser) { cfg.dim = v; refresh() }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val hint = TextView(this)
        hint.text = "Tap a day in the preview to switch it between work and day off. " +
            "Changes show in the preview; press the button above to put them on your lock screen. " +
            "Today is highlighted automatically and the lock screen refreshes itself at midnight."
        hint.setTextColor(Color.LTGRAY)

        root.addView(setBtn)
        root.addView(label("Title"))
        root.addView(title)
        root.addView(label("Note"))
        root.addView(note)
        root.addView(label("Theme"))
        root.addView(spin)
        root.addView(label("Dates"))
        root.addView(startBtn)
        root.addView(endBtn)
        root.addView(label("Calendar events"))
        root.addView(dotsSwitch)
        root.addView(label("Photo background"))
        root.addView(photoRow)
        root.addView(label("Photo darkness"))
        root.addView(seek)
        root.addView(hint)
        root.addView(preview)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#0b0d1a"))
        scroll.addView(root)
        setContentView(scroll)
        refresh()
    }

    private fun refresh() {
        if (cfg.end.isBefore(cfg.start)) cfg.end = cfg.start
        if (cfg.end.isAfter(cfg.start.plusDays(34))) cfg.end = cfg.start.plusDays(34)
        startBtn.text = "Start: " + cfg.start.format(fmt)
        endBtn.text = "End: " + cfg.end.format(fmt) + "  (max 35 days)"
        preview.setImageBitmap(Renderer.render(cfg, LocalDate.now()))
    }

    private fun pick(cur: LocalDate, done: (LocalDate) -> Unit) {
        DatePickerDialog(this, { _, y, m, d -> done(LocalDate.of(y, m + 1, d)) },
            cur.year, cur.monthValue - 1, cur.dayOfMonth).show()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 9) {
            val ok = res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED
            cfg.dots = ok
            dotsSwitch.isChecked = ok
            if (!ok) toast("Calendar permission was denied")
            refresh()
        }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req != 7 || res != RESULT_OK || uri == null) return
        try {
            val o = BitmapFactory.Options()
            o.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            var ss = 1
            while (o.outWidth / (ss * 2) >= 720 && o.outHeight / (ss * 2) >= 1600) ss *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = ss
            var src = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (src == null) { toast("Could not read that photo"); return }
            val orient = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val deg = when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) {
                val rm = Matrix()
                rm.postRotate(deg)
                src = Bitmap.createBitmap(src, 0, 0, src.width, src.height, rm, true)
            }
            val out = Bitmap.createBitmap(Renderer.W, Renderer.H, Bitmap.Config.ARGB_8888)
            val sc = maxOf(Renderer.W.toFloat() / src.width, Renderer.H.toFloat() / src.height)
            val m = Matrix()
            m.setScale(sc, sc)
            m.postTranslate((Renderer.W - src.width * sc) / 2f, (Renderer.H - src.height * sc) / 2f)
            Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
            File(filesDir, "bg.jpg").outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            cfg.photo = true
            refresh()
        } catch (e: Exception) {
            toast("Photo failed: " + e.message)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
