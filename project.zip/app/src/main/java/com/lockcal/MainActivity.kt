package com.lockcal

import android.app.Activity
import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.widget.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var preview: ImageView
    private lateinit var startBtn: Button
    private lateinit var endBtn: Button
    private val fmt = DateTimeFormatter.ofPattern("MMM d, yyyy")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        schedule(this)

        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        preview = ImageView(this)
        val w = (resources.displayMetrics.widthPixels * 0.8).toInt()
        val lp = LinearLayout.LayoutParams(w, w * Renderer.H / Renderer.W)
        lp.gravity = Gravity.CENTER_HORIZONTAL
        lp.topMargin = pad
        preview.layoutParams = lp
        preview.scaleType = ImageView.ScaleType.FIT_XY
        preview.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                val d = Renderer.dateAt(cfg, e.x / v.width * 360f, e.y / v.height * 800f)
                if (d != null) {
                    val s = cfg.off.toMutableSet()
                    if (!s.remove(d.toEpochDay())) s.add(d.toEpochDay())
                    cfg.off = s
                    refresh()
                }
            }
            true
        }

        val title = EditText(this)
        title.setText(cfg.title)
        title.hint = "Title"
        title.setTextColor(Color.WHITE)
        title.setHintTextColor(Color.GRAY)
        title.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { cfg.title = s.toString(); refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })

        startBtn = Button(this)
        endBtn = Button(this)
        startBtn.setOnClickListener { pick(cfg.start) { cfg.start = it; refresh() } }
        endBtn.setOnClickListener { pick(cfg.end) { cfg.end = it; refresh() } }

        val setBtn = Button(this)
        setBtn.text = "Set as lock screen now"
        setBtn.setOnClickListener {
            Thread {
                try {
                    applyLockScreen(this)
                    runOnUiThread { toast("Lock screen updated") }
                } catch (e: Exception) {
                    runOnUiThread { toast("Failed: " + e.message) }
                }
            }.start()
        }

        val hint = TextView(this)
        hint.text = "Tap a day in the preview to switch it between work and day off. " +
            "Today is highlighted automatically, and the lock screen refreshes itself every day."
        hint.setTextColor(Color.LTGRAY)

        root.addView(title)
        root.addView(startBtn)
        root.addView(endBtn)
        root.addView(setBtn)
        root.addView(hint)
        root.addView(preview)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#0b0d1a"))
        scroll.addView(root)
        setContentView(scroll)
        refresh()
    }

    private fun refresh() {
        if (cfg.end.isBefore(cfg.start)) cfg.end = cfg.start
        if (cfg.end.isAfter(cfg.start.plusDays(34))) cfg.end = cfg.start.plusDays(34)
        startBtn.text = "Start: " + cfg.start.format(fmt)
        endBtn.text = "End: " + cfg.end.format(fmt) + "  (max 35 days)"
        preview.setImageBitmap(Renderer.render(cfg, LocalDate.now()))
    }

    private fun pick(cur: LocalDate, done: (LocalDate) -> Unit) {
        DatePickerDialog(this, { _, y, m, d -> done(LocalDate.of(y, m + 1, d)) },
            cur.year, cur.monthValue - 1, cur.dayOfMonth).show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
